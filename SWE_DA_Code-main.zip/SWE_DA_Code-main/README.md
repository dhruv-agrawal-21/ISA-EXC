# IOT-

CNC Monitoring IOT Based Industrial Automation

[DISCLAIMER : REFERENCE IMAGE IS REPRESENTATIVE]

Reference Image from : https://www.youtube.com/watch?v=sfxUKqdnlmc&ab_channel=HughesArmstrongMiddleEast%28HAMideast%29

![image](https://github.com/user-attachments/assets/62b420bb-126a-4eec-99f2-7e2b8ccfbef5)


Reference Image from : https://www.mpx-transform.com/cnc-monitoring

![image](https://github.com/user-attachments/assets/43ceea94-7dd7-4596-8aa2-a34ff7ccaf7a)

